It has the entire frontend including auth, services, containers, models in ngValidation Folder

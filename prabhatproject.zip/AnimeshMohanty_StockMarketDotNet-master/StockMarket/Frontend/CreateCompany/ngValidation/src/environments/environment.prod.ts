export const environment = {
  production: true,
  path:"http://localhost:5003"
};

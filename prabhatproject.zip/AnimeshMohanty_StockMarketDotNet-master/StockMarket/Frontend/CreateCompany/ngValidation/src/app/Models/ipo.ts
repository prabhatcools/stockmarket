export class Ipo {
    Id:number;
    CompanyName:string;
    StockExchange:string;
    PricePerShare:string;
    NoOfShares:string;
    OpenDateTime:Date;
    Remarks:string;
}

export class Company {
    CompanyName:string="";
    Turnover:string="";
    Ceo:string="";
    BoardOfDirectors:string="";
    ListedInSe:string="";
    Sector:string="";
    Brief:string="";
    StockCode:string="";
}

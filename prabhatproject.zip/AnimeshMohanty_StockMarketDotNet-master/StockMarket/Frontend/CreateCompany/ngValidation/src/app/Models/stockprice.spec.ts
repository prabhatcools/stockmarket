import { Stockprice } from './stockprice';

describe('Stockprice', () => {
  it('should create an instance', () => {
    expect(new Stockprice()).toBeTruthy();
  });
});

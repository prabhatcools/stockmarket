API - Contains middleware, backend
Frontend/CreacteCompany/ngValidation - Creates the entire UI including landing, log-in, tables for stocks ,IPOs
Jenkins report
Docker Screenshots
IIS Screenshots
Postman Screenshots
DBScripts - Database table scripts both project and testing related


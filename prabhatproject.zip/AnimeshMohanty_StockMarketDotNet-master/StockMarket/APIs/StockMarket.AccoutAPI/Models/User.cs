﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMarket.AccoutAPI.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Uname { get; set; }
        public string Pwd { get; set; }
    }
}

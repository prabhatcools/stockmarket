﻿using System;
using System.Collections.Generic;

namespace StockMarket.AdminAPI.Models
{
    public partial class StockUser
    {
        public int Id { get; set; }
        public string Uname { get; set; }
    }
}

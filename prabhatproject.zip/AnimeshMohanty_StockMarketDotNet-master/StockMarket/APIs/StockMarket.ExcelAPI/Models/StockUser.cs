﻿using System;
using System.Collections.Generic;

namespace StockMarket.ExcelAPI.Models
{
    public partial class StockUser
    {
        public int Id { get; set; }
        public string Uname { get; set; }
        public string Pwd { get; set; }
    }
}
